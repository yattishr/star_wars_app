OTF and TTF: Death Star (Regular and Outlines)
Dennis Ludlow 2016 all rights reserved
by Sharkshock 
dennis@sharkshock.net

In a distant galaxy far, far away fans of this epic series had limited options when looking for the right font to use for their projects. Patience you must have young Jedi and thank me later you will. Enter Death Star : A grotesque display font featuring all caps that resembles the classic 80's style.
Geometrically rounded curves and limited stroke width variation combine for a retro look that will fit right into your blog, logo, or t-shirts. This version is limited to basic latin and punctuation only. There are a number of included alternates and ligatures so please check the included poster for these. 
You can take advantage of these with any program that supports OTF features. These can also be accessed via the glyphs panel in some programs. NOTE: Because the nature of overlapping glyphs alternates must be selected manually in the Outlines version from the Glyphs panel. 
Kerning is extremely tight and best displayed at larger sizes. Pair with Deutschlander for an authentic looking movie poster. 

The regular version is included but Outlined is only available with purchase of a commercial license or $15 donation via our homepage. 

This font like my others are free for personal use only as long as this readme file stays intact. For commercial use please contact me at dennis@sharkshock.net to discuss an end user license agreement. You can also visit www.sharkshock.net/license for more info. I also design custom fonts for
businesses, logos, and many other things. If you'd like to leave me a PayPal donation you can use my email address above. Your generosity will be most appreciated! 


visit www.sharkshock.net for more and take a bite out of BORING design!

tags: stylish, space, display, font, typeface, publishing, logo, title, book, cover, company, brand, branding, sans, serif, poster, headline, retro, star, stars, war, wars, jedi, knight, 80's, movie, movies, film, action, sci-fi, fantasy, childrens, kids